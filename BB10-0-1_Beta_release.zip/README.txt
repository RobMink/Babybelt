You will need to update the firmware on your E3 V3 board.  If you don't, you will melt the new pulleys.  The runout sensor has not been written into the firmware yet.  The print button uses pins highlighted in photo.

Thanks!